package registry.authz

import data.registry.authz.allow
import data.registry.authz.filter_resources

import rego.v1

allow_resource(user, operation, resource_type, resource_name) if {
	user_has_role(user, "admin")
}

allow_resource(user, operation, resource_type, resource_name) if {
	some grant in data.grants
	principal_matches(grant, user)
	operation_matches(grant, operation)
	resource_matches(grant, resource_type, resource_name)
}

user_has_role(user, role) if {
	some r in data.roles[user]
	r == role
}

principal_matches(grant, user) if {
	grant.principal == user
}

principal_matches(grant, user) if {
	grant.principal_role != ""
	user_has_role(user, grant.principal_role)
}

operation_matches(grant, operation) if {
	grant.operation == operation
}

operation_matches(grant, operation) if {
	grant.operation == "admin"
	operation in {"read", "write", "admin"}
}

operation_matches(grant, operation) if {
	grant.operation == "write"
	operation in {"read", "write"}
}

resource_matches(grant, resource_type, resource_name) if {
	grant.resource_type == resource_type
	grant.resource_pattern == "*"
}

resource_matches(grant, resource_type, resource_name) if {
	grant.resource_type == resource_type
	grant.resource_pattern_type == "exact"
	grant.resource_pattern == resource_name
}

resource_matches(grant, resource_type, resource_name) if {
	grant.resource_type == resource_type
	grant.resource_pattern_type == "prefix"
	startswith(resource_name, grant.resource_pattern)
}
